const mysql = require("promise-mysql");

exports.handler = async (event, context) => {
  const dbConfig = {
    host: "taoc-prd.cegbt7mmflwn.us-west-1.rds.amazonaws.com",
    port: "3306",
    user: "super_adm",
    password: "taocfreq7_pass",
    database: "dbtaoc"
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    const {licenseCode} = JSON.parse(event.body);

    if (!licenseCode) {
      return {
        statusCode: 400,
        body: JSON.stringify({message: "License code is required"})
      };
    }

    const query = "SELECT * FROM license_codes WHERE code = ? AND user_id IS NULL";
    const result = await connection.query(query, [licenseCode]);

    await connection.end();

    if (result.length > 0) {
      return {
        statusCode: 200,
        body: JSON.stringify({isValid: true, message: "License code is valid and not associated with a user"})
      };
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({isValid: false, message: "License code is invalid or already associated with a user"})
      };
    }
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({message: `Error checking license: ${error.message}`})
    };
  }
};
